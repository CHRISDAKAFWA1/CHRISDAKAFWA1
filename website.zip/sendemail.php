<?php
 
 
   if (isset($_POST['submit'])) {  
     $name = $_POST['name'];
     $email = $_POST['email'];
     $subject = $_POST['subject'];
     $message = $_POST['message'];
     {
     $mailTo = "info@cfservice.co.za";
     $subject = $subject;
     $txt = "you have received an email from -- ".$name.".\n\n"."email - ".$email.".\n\n".$message;
    

     mail($mailTo, $subject, $txt);
     header("Location: index.php?mailsend");
  
   }
   }
  ?>
