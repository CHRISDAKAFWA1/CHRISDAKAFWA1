
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>c&f services</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Vendor CSS Files -->
  
 <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
 <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

</head>

<body>
 
  <header id="header" class="fixed-top d-flex align-items-center">
    <div class="container d-flex justify-content-between">

      <div class="logo">
        <h1><a href="index.html">C<span>&</span>F SERVICES (PTY) LTD</a></h1>
        
       
      
      </div>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto active" href="#hero">Home</a></li>
          <li><a class="nav-link scrollto" href="#about">About</a></li>
          <li><a class="nav-link scrollto" href="#services">Services</a></li>
          <li><a class="nav-link scrollto" href="#team">Team</a></li>
          
          
          <li><a class="nav-link scrollto" href="contact.php">Contact</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->

  <!-- ======= hero Section ======= -->
  <section id="hero">
    <div class="hero-container">
      <div id="heroCarousel" class="carousel slide carousel-fade" data-bs-ride="carousel" data-bs-interval="5000">

        <ol id="hero-carousel-indicators" class="carousel-indicators"></ol>

        <div class="carousel-inner" role="listbox">

          <div class="carousel-item active" style="background-image: url(assets/img/hero-carousel/1.jpg)">
            <div class="carousel-container">
              <div class="container">
              <div class="imgs"><img src="assets/img/background/logo3.png" alt=""></div>
                <h2 class="animate__animated animate__fadeInDown">C<span>&</span>F SERVICES (PTY) LTD</h2>
                <p class="animate__animated animate__fadeInUp">Helping you to make your life easier</p>
                <a href="#about" class="btn-get-started scrollto animate__animated animate__fadeInUp">Get Started</a>
              </div>
            </div>
          </div>

          <div class="carousel-item" style="background-image: url(assets/img/hero-carousel/3.jpeg)">
            <div class="carousel-container">
              <div class="container">
              <div class="imgs"><img src="assets/img/background/logo3.png" alt=""></div>
                <h2 class="animate__animated animate__fadeInDown">C<span>&</span>F SERVICES (PTY) LTD</h2>
                <p class="animate__animated animate__fadeInUp"> Dit help jou om jou lewe maaklike te maak</p>
                <a href="#about" class="btn-get-started scrollto animate__animated animate__fadeInUp">Get Started</a>
              </div>
            </div>
          </div>

          <div class="carousel-item" style="background-image: url(assets/img/hero-carousel/4.jpg)">
            <div class="carousel-container">
              <div class="container">
              <div class="imgs"><img src="assets/img/background/logo3.png" alt=""></div>
                <h2 class="animate__animated animate__fadeInDown">C<span>&</span>F SERVICES (PTY) LTD</h2>
                <p class="animate__animated animate__fadeInUp">Kukunceda wenze ubomi bakho bube lula</p>
                <a href="#about" class="btn-get-started scrollto animate__animated animate__fadeInUp">Get Started</a>
              </div>
            </div>
          </div>

        </div>

        <a class="carousel-control-prev" href="#heroCarousel" role="button" data-bs-slide="prev">
          <span class="carousel-control-prev-icon bi bi-chevron-left" aria-hidden="true"></span>
        </a>

        <a class="carousel-control-next" href="#heroCarousel" role="button" data-bs-slide="next">
          <span class="carousel-control-next-icon bi bi-chevron-right" aria-hidden="true"></span>
        </a>

      </div>
    </div>
  </section><!-- End Hero Section -->

  <main id="main">

    <!-- ======= About Section ======= -->
    <div id="about" class="about-area area-padding">
      <div class="container">
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="section-headline text-center">
              <h2>About C&F SERVICES</h2>
              <p class="para">our service caters for corporates with large fleets as well as individuals.<br /> We remove the hassle by performing renewals nationally and to remove the risk of outdated discs<br /> to ensure that our clients can concentrate on what's important.</p>
            </div>
          </div>
        </div>
        <div class="row">
          <!-- single-well start-->
          <div class="col-md-6 col-sm-6 col-xs-12">
            <div class="well-left">
              <div class="single-well">
                <a href="#">
                  <img src="assets/img/about/3.jpg" alt="">
                </a>
              </div>
            </div>
          </div>
          <!-- single-well end-->
          <div class="col-md-6 col-sm-6 col-xs-12">
            <div class="well-middle">
              <div class="single-well">
                <a href="#">
                  <h4 class="sec-head">our specialties</h4>
                </a>
                <p>
                  never to wait in queues we work hand in hand with traffic dipartment
                </p>
                <ul>
                  <li>
                    <i class="bi bi-check"></i> License renewal
                  </li>
                  <li>
                    <i class="bi bi-check"></i> number plates
                  </li>
                  <li>
                    <i class="bi bi-check"></i> roadworthy
                  </li>
                  <li>
                    <i class="bi bi-check"></i> change of ownership
                  </li>
                  <li>
                    <i class="bi bi-check"></i> paperwork problems
                  </li>
                  <li>
                    <i class="bi bi-check"></i> Engine Clearance
                  </li>
                   <li>
                    <i class="bi bi-check"></i> De-Registration / Re-Registration
                  </li>
                  
                  
                </ul>
              </div>
            </div>
          </div>
          <!-- End col-->
        </div>
      </div>
    </div><!-- End About Section -->

    <!-- ======= Services Section ======= -->
    <div id="services" class="services-area area-padding">
      <div class="container">
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="section-headline services-head text-center">
              <h2>Our Services</h2>
            </div>
          </div>
        </div>
        
        
        
        <div class="row text-center">
          <!-- Start Left services -->
          <div class="col-md-4 col-sm-4 col-xs-12">
            <div class="about-move">
              <div class="services-details">
                <div class="single-services">
                  <a class="services-icon" href="#">
                  
                  <img src="assets/img/plate/1.jpg" alt="">
                  </a>
                  <h4>Number Plates</h4>
                  <p>
                    we deal with all kinds of number plate based in Cape Town.
                  </p>
                </div>
              </div>
              <!-- end about-details -->
            </div>
          </div>
          <div class="col-md-4 col-sm-4 col-xs-12">
            <div class="about-move">
              <div class="services-details">
                <div class="single-services">
                  <a class="services-icon" href="#">
                   
                    <img src="assets/img/plate/2.jpg" alt="">
                  </a>
                  <h4>License Disk</h4>
                  <p>
                    we deal with all kinds of license disks based in Cape Town.
                  </p>
                </div>
              </div>
              <!-- end about-details -->
            </div>
          </div>
          <div class="col-md-4 col-sm-4 col-xs-12">
            <!-- end col-md-4 -->
            <div class=" about-move">
              <div class="services-details">
                <div class="single-services">
                  <a class="services-icon" href="#">
                   <img src="assets/img/plate/3.jpg" alt=""> 
                  </a>
                  <h4>roadworthy</h4>
                  <p>
                    we take your car for roadworthy while you relaxing.
                  </p>
                </div>
              </div>
              <!-- end about-details -->
            </div>
          </div>
          <div class="col-md-4 col-sm-4 col-xs-12">
            <!-- end col-md-4 -->
            <div class=" about-move">
              <div class="services-details">
                <div class="single-services">
                  <a class="services-icon" href="#">
                    <img src="assets/img/plate/4.jpg" alt=""> 
                  </a>
                  <h4>change of ownership</h4>
                  <p>
                    we assist you to change ownership we do all the hard work for you.
                  </p>
                </div>
              </div>
              <!-- end about-details -->
            </div>
          </div>
          <div class="col-md-4 col-sm-4 col-xs-12">
            <!-- end col-md-4 -->
            <div class=" about-move">
              <div class="services-details">
                <div class="single-services">
                  <a class="services-icon" href="#">
                   <img src="assets/img/plate/engine.jpg" alt=""> 
                  </a>
                  <h4>Engine Clearance</h4>
                  <p>
                    
                  </p>
                </div>
              </div>
              <!-- end about-details -->
            </div>
          </div>
          <div class="col-md-4 col-sm-4 col-xs-12">
            <!-- end col-md-4 -->
            <div class=" about-move">
              <div class="services-details">
                <div class="single-services">
                  <a class="services-icon" href="#">
                   <img src="assets/img/plate/paper.png" alt=""> 
                  </a>
                  <h4>Paperwork Problems</h4>
                  <p>
                    
                  </p>
                </div>
              </div>
              <!-- end about-details -->
            </div>
          </div>
          <!-- End Left services -->

    <!-- ======= Team Section ======= -->
    <div id="team" class="our-team-area area-padding">
      <div class="container">
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="section-headline text-center">
              <h2>Our special Team</h2>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-3 col-sm-3 col-xs-12">
            <div class="single-team-member">
              <div class="team-img">
                <a href="#">
                  <img src="assets/img/team/.jpg" alt="">
                </a>
                <div class="team-social-icon text-center">
                  <ul>
                    <li>
                      <a href="#">
                        <i class="bi bi-facebook"></i>
                      </a>
                    </li>
                    <li>
                      <a href="#">
                        <i class="bi bi-twitter"></i>
                      </a>
                    </li>
                    <li>
                      <a href="#">
                        <i class="bi bi-instagram"></i>
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
              <div class="team-content text-center">
                <h4>Cassiem and Fagma</h4>
                <p>CEO</p>
              </div>
            </div>
          </div>
         
          <p class="par">At C&F Services we believe there is a better way to assist companies with fleet management. A more valuable less hassling way where companies can focus on what's important to their business and let us worry about the rest.
                    <br /><br />
                    
                    Our Directors noticed a gap in the market, the time-consuming, high-costing, administration-heavy aspects that went along with traffic fine management and vehicle license renewals inspired our directors in 2020 to start this business.</p>
          <!-- End column -->
        </div>
      </div>
    </div><!-- End Team Section -->

    <!-- ======= Rviews Section ======= -->
    <div class="reviews-area">
      <div class="row g-0">
        <div class="col-lg-6">
          <img src="assets/img/about/3.jpg" alt="" class="img-fluid">
        </div>
        <div class="col-lg-6 work-right-text d-flex align-items-center">
          <div class="px-5 py-5 py-lg-0">
            <h2>working for you</h2>
            <h5>license disk, change of ownership, number plates, roadworthy and many more.</h5>
            <a href="#contact" class="ready-btn scrollto">Contact us</a>
          </div>
        </div>
      </div>
    </div><!-- End Rviews Section -->

   

    <!-- ======= Suscribe Section ======= -->
    <div class="suscribe-area">
      <div class="container">
        <div class="row">
          <div class="col-lg-12 col-md-12 col-sm-12 col-xs=12">
            <div class="suscribe-text text-center">
              <h3>Welcome to C&F SERVICES (PTY) LTD</h3>
              <a class="sus-btn" href="contact.php">Get A quote</a>
            </div>
          </div>
        </div>
      </div>
    </div><!-- End Suscribe Section -->

    <!-- ======= Contact Section ======= -->
    <div id="contact" class="contact-area">
      <div class="contact-inner area-padding">
        <div class="contact-overly"></div>
        <div class="container ">
          <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="section-headline text-center">
                <h2>Contact us</h2>
              </div>
            </div>
          </div>
          <div class="row">
            <!-- Start contact icon column -->
            <div class="col-md-4">
              <div class="contact-icon text-center">
                <div class="single-icon">
                  <i class="bi bi-phone"></i>
                  <p>
                    Office: 0605487426<br />
                    Cell  : 0836555572<br />
                    
                  </p>
                </div>
              </div>
            </div>
            <!-- Start contact icon column -->
            <div class="col-md-4">
              <div class="contact-icon text-center">
                <div class="single-icon">
                  <i class="bi bi-envelope"></i>
                  
                  <p>
                    info@cfservice.co.za
                    <br>
                    <span>Web: <a href="https://www.cfservice.co.za">www.cfservice.co.za</a> </span>
                  </p>
                </div>
              </div>
            </div>
            <!-- Start contact icon column -->
            <div class="col-md-4">
              <div class="contact-icon text-center">
                <div class="single-icon">
                  <i class="bi bi-geo-alt"></i>
                  <p>
                    Location: 31 orchid crescent silvertown<br>
                    <span>Monday-Friday (8am-6pm)</span>
                  </p>
                </div>
              </div>
            </div>
          </div>
          <div class="row">

           
  </main>
 
  <footer>
    <div class="footer-area">
      <div class="container">
        <div class="row">
          <div class="col-md-4">
            <div class="footer-content">
              <div class="footer-head">
                <div class="footer-logo">
                  <h2>C<span>&</span>F SERVICES</h2>
                </div>

                <p>best services you can get.</p>
                <div class="footer-icons">
                  <ul>
                    <li>
                      <a href="#"><i class="bi bi-facebook"></i></a>
                    </li>
                    <li>
                      <a href="#"><i class="bi bi-twitter"></i></a>
                    </li>
                    <li>
                      <a href="#"><i class="bi bi-instagram"></i></a>
                    </li>
                    <li>
                      <a href="#"><i class="bi bi-linkedin"></i></a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <!-- end single footer -->
          <div class="col-md-4">
            <div class="footer-content">
              <div class="footer-head">
                <h4>information</h4>
                <p>
                  we are located in silvertown close to vangate mall.
                </p>
                <div class="footer-contacts">
                  <p><span>Office:</span> 0605487426</p>
                  <p><span>Cell:</span> 0836555572</p>
                  <p><span>Email:</span> info@cfservice.co.za</p>
                  <p><span>Working Hours:</span> Monday-Friday (8am-6pm)</p>
                </div>
              </div>
            </div>
          </div>
          <!-- end single footer -->
          <div class="col-md-4">
            <div class="footer-content">
              <div class="footer-head">
                <h4>facebook</h4>
                <div class="flicker-img">
                  <a href="#"><img src="assets/img/hero-carousel/4.jpg" alt=""></a>
                  <a href="#"><img src="assets/img/hero-carousel/car1.jpeg" alt=""></a>
                  <a href="#"><img src="assets/img/hero-carousel/car3.jpg" alt=""></a>
                  <a href="#"><img src="assets/img/hero-carousel/5.jpeg" alt=""></a>
                  <a href="#"><img src="assets/img/hero-carousel/3.jpeg" alt=""></a>
                  <a href="#"><img src="assets/img/hero-carousel/1.jpg" alt=""></a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="footer-area-bottom">
      <div class="container">
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="copyright text-center">
              <p>
                &copy; Copyright <strong>c&f</strong>. All Rights Reserved
              </p>
            </div>
            <div class="credits">
             
            </div>
          </div>
        </div>
      </div>
    </div>
  </footer><!-- End  Footer -->

  <div id="preloader"></div>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>