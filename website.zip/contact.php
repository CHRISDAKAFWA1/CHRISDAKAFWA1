
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>c&f services</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Vendor CSS Files -->
  
 <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
 <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

</head>

<body>
 
  <header id="header" class="fixed-top d-flex align-items-center">
    <div class="container d-flex justify-content-between">

      <div class="logo">
        <h1><a href="index.html">C<span>&</span>F SERVICES (PTY) LTD</a></h1>
        
       
      
      </div>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto" href="index.php">Home</a></li>
           <li><a class="nav-link scrollto" href="#contact">Contact</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->

  <!-- ======= hero Section ======= -->
  <section id="hero">
    <div class="hero-container">
      <div id="heroCarousel" class="carousel slide carousel-fade" data-bs-ride="carousel" data-bs-interval="5000">

        <ol id="hero-carousel-indicators" class="carousel-indicators"></ol>

        <div class="carousel-inner" role="listbox">

          <div class="carousel-item active" style="background-image: url(assets/img/hero-carousel/1.jpg)">
            <div class="carousel-container">
              <div class="container">
              <div class="imgs"><img src="assets/img/background/logo3.png" alt=""></div>
                <h2 class="animate__animated animate__fadeInDown">C<span>&</span>F SERVICES (PTY) LTD</h2>
                <p class="animate__animated animate__fadeInUp">Helping you to make your life easier</p>
                <a href="#contact" class="btn-get-started scrollto animate__animated animate__fadeInUp">Get Started</a>
              </div>
            </div>
          </div>

          <div class="carousel-item" style="background-image: url(assets/img/hero-carousel/3.jpeg)">
            <div class="carousel-container">
              <div class="container">
              <div class="imgs"><img src="assets/img/background/logo3.png" alt=""></div>
                <h2 class="animate__animated animate__fadeInDown">C<span>&</span>F SERVICES (PTY) LTD</h2>
                <p class="animate__animated animate__fadeInUp"> Dit help jou om jou lewe maaklike te maak</p>
                <a href="#contact" class="btn-get-started scrollto animate__animated animate__fadeInUp">Get Started</a>
              </div>
            </div>
          </div>

          <div class="carousel-item" style="background-image: url(assets/img/hero-carousel/4.jpg)">
            <div class="carousel-container">
              <div class="container">
              <div class="imgs"><img src="assets/img/background/logo3.png" alt=""></div>
                <h2 class="animate__animated animate__fadeInDown">C<span>&</span>F SERVICES (PTY) LTD</h2>
                <p class="animate__animated animate__fadeInUp">Kukunceda wenze ubomi bakho bube lula</p>
                <a href="#contact" class="btn-get-started scrollto animate__animated animate__fadeInUp">Get Started</a>
              </div>
            </div>
          </div>

        </div>

        <a class="carousel-control-prev" href="#heroCarousel" role="button" data-bs-slide="prev">
          <span class="carousel-control-prev-icon bi bi-chevron-left" aria-hidden="true"></span>
        </a>

        <a class="carousel-control-next" href="#heroCarousel" role="button" data-bs-slide="next">
          <span class="carousel-control-next-icon bi bi-chevron-right" aria-hidden="true"></span>
        </a>

      </div>
    </div>
  </section><!-- End Hero Section -->

  <main id="main" class="main">

    

    

    <!-- ======= Contact Section ======= -->
    <div id="contact" class="contact-areas">
      <div class="contact-inner area-padding">
        <div class="contact-overly"></div>
        <div class="container ">
          <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="section-headline text-center">
                <h2>Contact us</h2>
              </div>
            </div>
          </div>
          <div class="row">
            <!-- Start contact icon column -->
            <div class="col-md-4">
              <div class="contact-icon text-center">
                <div class="single-icon">
                  <i class="bi bi-phone"></i>
                  <p>
                    Office: 0605487426<br />
                    Cell  : 0836555572<br />
                    
                  </p>
                </div>
              </div>
            </div>
            <!-- Start contact icon column -->
            <div class="col-md-4">
              <div class="contact-icon text-center">
                <div class="single-icon">
                  <i class="bi bi-envelope"></i>
                  <p>
                    info@cfservice.co.za
                    <br>
                    <span>Web: <a href="https://www.cfservice.co.za">www.cfservice.co.za</a> </span>
                  </p>
                </div>
              </div>
            </div>
            <!-- Start contact icon column -->
            <div class="col-md-4">
              <div class="contact-icon text-center">
                <div class="single-icon">
                  <i class="bi bi-geo-alt"></i>
                  <p>
                    Location: 31 orchid crescent silvertown<br>
                    <span> Monday-Friday (8am-6pm)</span>
                  </p>
                </div>
              </div>
            </div>
          </div>
           </div>
              </div>
            </div>
          </div>
          </div>
          <div class="rowz">

            <!-- Start Google Map -->
            <div class="col-m6">
              <!-- Start Map -->
              <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3309.1417428150903!2d18.525675450160165!3d-33.96319613129927!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1dcc5b54a56789e5%3A0xa97175356d4d89d2!2s31%20Orchid%20Cres%2C%20Silvertown%2C%20Cape%20Town%2C%207764!5e0!3m2!1sen!2sza!4v1629907525527!5m2!1sen!2sza" width="100%" height="380" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
             
              <!-- End Map -->
            </div>
            <!-- End Google Map -->
         <div class="myform">   
        <form class="contact" action="sendemail.php" method="post">
          <div class="input">
          <input type="text" name="name" required class="text-box" placeholder="Name" >
           
          </div>
         
          <div class="input">
          <input type="text" name="email" required class="text-box" placeholder="Email" >
          </div>
          <div class="input">
          <input type="text" name="subject" required class="text-box" placeholder="Subject" >
          </div>
          <div class="textarea">
          <textarea name="message" required rows="5" placeholder="Message" ></textarea>
          </div>
          <div class="button">
          <button type="submit" name="submit">Send Message</button>
          </div>
        </form>
</div>
</div>
   </main>

  <footer>
    <div class="footer-area">
      <div class="container">
        <div class="row">
          <div class="col-md-4">
            <div class="footer-content">
              <div class="footer-head">
                <div class="footer-logo">
                  <h2>C<span>&</span>F SERVICES</h2>
                </div>

                <p>best services you can get.</p>
                <div class="footer-icons">
                  <ul>
                    <li>
                      <a href="#"><i class="bi bi-facebook"></i></a>
                    </li>
                    <li>
                      <a href="#"><i class="bi bi-twitter"></i></a>
                    </li>
                    <li>
                      <a href="#"><i class="bi bi-instagram"></i></a>
                    </li>
                    <li>
                      <a href="#"><i class="bi bi-linkedin"></i></a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <!-- end single footer -->
          <div class="col-md-4">
            <div class="footer-content">
              <div class="footer-head">
                <h4>information</h4>
                <p>
                  we are located in silvertown close to vangate mall.
                </p>
                <div class="footer-contacts">
                  <p><span>Office:</span> 0605487426</p>
                  <p><span>Cell:</span> 0836555572</p>
                  <p><span>Email:</span> info@cfservice.co.za</p>
                  <p><span>Working Hours:</span> Monday-Friday (8am-6pm)</p>
                </div>
              </div>
            </div>
          </div>
          <!-- end single footer -->
          <div class="col-md-4">
            <div class="footer-content">
              <div class="footer-head">
                <h4>facebook</h4>
                <div class="flicker-img">
                  <a href="#"><img src="assets/img/hero-carousel/4.jpg" alt=""></a>
                  <a href="#"><img src="assets/img/hero-carousel/car1.jpeg" alt=""></a>
                  <a href="#"><img src="assets/img/hero-carousel/car3.jpg" alt=""></a>
                  <a href="#"><img src="assets/img/hero-carousel/5.jpeg" alt=""></a>
                  <a href="#"><img src="assets/img/hero-carousel/3.jpeg" alt=""></a>
                  <a href="#"><img src="assets/img/hero-carousel/1.jpg" alt=""></a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="footer-area-bottom">
      <div class="container">
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="copyright text-center">
              <p>
                &copy; Copyright <strong>c&f</strong>. All Rights Reserved
              </p>
            </div>
            <div class="credits">
              
            </div>
          </div>
        </div>
      </div>
    </div>
  </footer><!-- End  Footer -->

  <div id="preloader"></div>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>